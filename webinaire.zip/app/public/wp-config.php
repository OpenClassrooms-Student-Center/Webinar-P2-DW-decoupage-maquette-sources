<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'paOqo+oqCKGLfeTs0pR0MQNHGQSVYawmssV3R73zDUYhTr5Vuozbcil8uAuMZB9UkeeBqI75l0h8/66K0Nzx0w==');
define('SECURE_AUTH_KEY',  'g+l8i59no/EWLdKT4MrgrjdqLWsqDVByCB/5ggHLG+vOC+17e7PwY91ZHY2P4ATs/xduBl3G3Q/s6rCi8EHV1A==');
define('LOGGED_IN_KEY',    'USV/aDniN+oDSaPr0WZur12aZ8mnrFgaz0IsrrEjRCZzzANyqJWgVn0XUqNPIIgENdV0BEUlQWOY5cWQ7vct7w==');
define('NONCE_KEY',        'f3lb65Hyn/+2s4VBY+8/Is65bAQBbXDT7qtHGkjfyg/fCOwoALQMqZPppylUZRswTQxBbZ3PS1VRI/YYuYsEpQ==');
define('AUTH_SALT',        'pm7wlhYUvLnERvYVczmdpkOCEOpE6EQc0QYvrZF2Nz0XbU2oRAK+F1IRshotczVQhuH/pvfbtZmF2h/0zZE1UA==');
define('SECURE_AUTH_SALT', '9sVD+wGyvb9exS4vy81QKv2hHsV8fVmh0qeGqW2iliQh805+u2QrSJM3AHZxc4S+yFHNXcy6CPBRZrErRTU0gQ==');
define('LOGGED_IN_SALT',   'm3NW3+AEJM52Xf89GZWy3ivwGIE5G60ddjkMCnRJBDowzTeBEgfaPw8t3bvH7XaX0LAy7Ecebx/EtVOGgjjMTg==');
define('NONCE_SALT',       's4LxTYVWOIZxBkWnTFU9jss46pPNafc9kkxCt6PRt/x0epevlsFHJRHXrXbF/apmY7y9obuzmOsS5rfbX9b/yQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
